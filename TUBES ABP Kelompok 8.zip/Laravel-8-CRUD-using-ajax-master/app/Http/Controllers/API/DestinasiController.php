<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\API\BaseController as BaseController;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Validator;
use App\Models\Destinasi;
use App\Http\Resources\DestinasiResource;

class DestinasiController extends BaseController
{
    public function index()
    {
        $Destinasi = Destinasi::all();
        return $this->sendResponse(DestinasiResource::collection($Destinasi), 'Posts fetched.');
    }
    
    public function store(Request $request)
    {
        $input = $request->all();
        $validator = Validator::make($input, [
            'nama_destinasi' => 'required',
            'lokasi_destinasi' => 'required',
            'deskripsi_destinasi' => 'required',
            'jenis_destinasi' => 'required',
            'harga_destinasi' => 'required',
            'contact_person' => 'required',
        ]);
        if($validator->fails()){
            return $this->sendError($validator->errors());       
        }
        $Destinasi = Destinasi::create($input);
        return $this->sendResponse(new DestinasiResource($Destinasi), 'Post created.');
    }
   
    public function show($id)
    {
        $destinasi = Destinasi::find($id);
        if (is_null($destinasi)) {
            return $this->sendError('Post does not exist.');
        }
        return $this->sendResponse(new DestinasiResource($destinasi), 'Post fetched.');
    }
 
    public function update(Request $request, Destinasi $destinasi)
    {
        $input = $request->all();

        $validator = Validator::make($input, [
            'nama_destinasi' => 'required',
            'lokasi_destinasi' => 'required',
            'deskripsi_destinasi' => 'required',
            'jenis_destinasi' => 'required',
            'harga_destinasi' => 'required',
            'contact_person' => 'required',
        ]);

        if($validator->fails()){
            return $this->sendError($validator->errors());       
        }

        $destinasi->nama_destinasi = $input['nama_destinasi'];
        $destinasi->lokasi_destinasi = $input['lokasi_destinasi'];
        $destinasi->deskripsi_destinasi = $input['deskripsi_destinasi'];
        $destinasi->jenis_destinasi = $input['jenis_destinasi'];
        $destinasi->harga_destinasi = $input['harga_destinasi'];
        $destinasi->contact_person = $input['contact_person'];
        $destinasi->save();
        
        return $this->sendResponse(new DestinasiResource($destinasi), 'Post updated.');
    }
   
    public function destroy(Destinasi $destinasi)
    {
        $destinasi->delete();
        return $this->sendResponse([], 'Post deleted.');
    }
    
}
