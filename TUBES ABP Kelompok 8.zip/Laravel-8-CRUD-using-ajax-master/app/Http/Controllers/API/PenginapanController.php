<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Validator;
use App\Models\Penginapan;
use App\Http\Controllers\API\BaseController as BaseController;
use App\Http\Resources\PenginapanResource;

class PenginapanController extends  BaseController
{
    public function index()
    {
        $data = Penginapan::latest()->get();
        return response()->json([PenginapanResource::collection($data), 'Programs fetched.']);
    }

    public function store(Request $request)
    {
        $input = $request->all();
        $validator = Validator::make($input, [
            'nama_penginapan' => 'required|string|max:255',
            'lokasi_penginapan' => 'required',
            'deskripsi_penginapan' => 'required',
            'jenis_penginapan' => 'required',
            'harga_penginapan' => 'required',
            'contact_person' => 'required',
        ]);
        if($validator->fails()){
            return $this->sendError($validator->errors());       
        }
        $penginapan = Penginapan::create($input);
        return $this->sendResponse(new PenginapanResource($penginapan), 'Post created.');
    }

    public function show($id)
    {
        $penginapan = Penginapan::find($id);
        if (is_null($penginapan)) {
            return $this->sendError('Post does not exist.');
        }
        return $this->sendResponse(new PenginapanResource($penginapan), 'Post fetched.');
    }

    public function update(Request $request, Penginapan $penginapan)
    {
        $input = $request->all();

        $validator = Validator::make($input, [
            'nama_penginapan' => 'required|string|max:255',
            'lokasi_penginapan' => 'required',
            'deskripsi_penginapan' => 'required',
            'jenis_penginapan' => 'required',
            'harga_penginapan' => 'required',
            'contact_person' => 'required',
        ]);

        if($validator->fails()){
            return $this->sendError($validator->errors());       
        }

        $penginapan->nama_penginapan = $input['nama_penginapan'];
        $penginapan->lokasi_penginapan = $input['lokasi_penginapan'];
        $penginapan->deskripsi_penginapan = $input['deskripsi_penginapan'];
        $penginapan->jenis_penginapan = $input['jenis_penginapan'];
        $penginapan->harga_penginapan = $input['harga_penginapan'];
        $penginapan->contact_person = $input['contact_person'];
        $penginapan->save();
        
        return $this->sendResponse(new PenginapanResource($penginapan), 'Post updated.');
    }

    public function destroy(Penginapan $penginapan)
    {
        $penginapan->delete();

        return response()->json('penginapan deleted successfully');
    }
    
}
