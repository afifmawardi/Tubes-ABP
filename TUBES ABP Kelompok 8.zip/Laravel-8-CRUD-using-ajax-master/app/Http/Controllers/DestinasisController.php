<?php
         
namespace App\Http\Controllers;
          
use App\Models\Destinasi;
use Illuminate\Http\Request;
use DataTables;
        
class DestinasisController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
   
        $Destinasis = Destinasi::latest()->get();
        
        if ($request->ajax()) {
            $data = Destinasi::latest()->get();
            return Datatables::of($data)
                    ->addIndexColumn()
                    ->addColumn('action', function($row){
   
                           $btn = '<a href="javascript:void(0)" data-toggle="tooltip"  data-id="'.$row->id.'" data-original-title="Edit" class="edit btn btn-primary btn-sm editDestinasi">Edit</a>';
   
                           $btn = $btn.' <a href="javascript:void(0)" data-toggle="tooltip"  data-id="'.$row->id.'" data-original-title="Delete" class="btn btn-danger btn-sm deleteDestinasi">Delete</a>';
    
                            return $btn;
                    })
                    ->rawColumns(['action'])
                    ->make(true);
        }
      
        return view('Destinasi',compact('Destinasis'));
    }
     
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        Destinasi::updateOrCreate(['id' => $request->destinasi_id],
        ['nama_destinasi' => $request->nama_destinasi, 
        'lokasi_destinasi' => $request->lokasi_destinasi,
        'deskripsi_destinasi' => $request->deskripsi_destinasi,
        'jenis_destinasi' => $request->jenis_destinasi,
        'harga_destinasi' => $request->harga_destinasi,
        'contact_person' => $request->contact_person
    ]);        
   
        return response()->json(['success'=>'Destinasi saved successfully.']);
    }
    
    public function edit($id)
    {
        $destinasi = Destinasi::find($id);
        return response()->json($destinasi);
    }
  
    
    public function destroy($id)
    {
        Destinasi::find($id)->delete();
     
        return response()->json(['success'=>'Destinasi deleted successfully.']);
    }
}