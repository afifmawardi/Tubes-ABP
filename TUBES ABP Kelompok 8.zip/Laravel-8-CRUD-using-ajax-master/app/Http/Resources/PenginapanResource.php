<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class PenginapanResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
        'id' => $this->id,
        'nama_penginapan' => $this->nama_penginapan,
        'lokasi_penginapan' => $this->lokasi_penginapan,
        'deskripsi_penginapan' => $this->deskripsi_penginapan,
        'jenis_penginapan' => $this->jenis_penginapan,
        'harga_penginapan' => $this->harga_penginapan,
        'contact_person' => $this->contact_person,
        'created_at' => $this->created_at,
        'updated_at' => $this->updated_at,
        ];
    }
}
