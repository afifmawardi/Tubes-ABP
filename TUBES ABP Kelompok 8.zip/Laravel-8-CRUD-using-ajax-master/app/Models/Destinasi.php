<?php
  
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;

use Illuminate\Database\Eloquent\Model;
 
class Destinasi extends Model
{
    use HasFactory;
    protected $fillable = [
        'nama_destinasi',
        'lokasi_destinasi',
        'deskripsi_destinasi',
        'jenis_destinasi',
        'harga_destinasi',
        'contact_person'
    ];
}