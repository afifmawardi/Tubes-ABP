<!DOCTYPE html>
<html>
<head>
    <title>Destinasi Pariwisata Indonesia</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" rel="stylesheet">
</head>
<body>
    
<div class="container">
    <h1>Destinasi Pariwisata Indonesia</h1>
    <br>
    <a class="btn btn-success" href="javascript:void(0)" id="createNewDestinasi"> Create New Destinasi</a>
    <br>
    <table class="table table-bordered data-table">
        <thead>
            <tr>
                <th>No</th>
                <th>nama_destinasi</th>
                <th>lokasi_destinasi</th>
                <th>deskripsi_destinasi</th>
                <th>jenis_destinasi</th>
                <th>harga_destinasi</th>
                <th>contact_person</th>
                <th width="300px">Action</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>
   
<div class="modal fade" id="ajaxModel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="modelHeading"></h4>
            </div>
            <div class="modal-body">
                <form id="destinasiForm" name="destinasiForm" class="form-horizontal">
                   <input type="hidden" name="destinasi_id" id="destinasi_id">
                    <div class="form-group">
                        <label for="name" class="col-sm-2 control-label">nama_destinasi</label>
                        <div class="col-sm-12">
                            <input type="text" class="form-control" id="nama_destinasi" name="nama_destinasi" placeholder="Enter nama_destinasi" value="" maxlength="50" required="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">lokasi_destinasi</label>
                        <div class="col-sm-12">
                            <textarea id="lokasi_destinasi" name="lokasi_destinasi" required="" placeholder="Enter lokasi_destinasi" class="form-control"></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                       <label class="col-sm-2 control-label">deskripsi_destinasi</label>
                       <div class="col-sm-12">
                           <textarea id="deskripsi_destinasi" name="deskripsi_destinasi" required="" placeholder="Enter deskripsi_destinasi" class="form-control"></textarea>
                       </div>
                   </div>
                   <div class="form-group">
                      <label class="col-sm-2 control-label">jenis_destinasi</label>
                      <div class="col-sm-12">
                          <textarea id="jenis_destinasi" name="jenis_destinasi" required="" placeholder="Enter jenis_destinasi" class="form-control"></textarea>
                      </div>
                   </div>
                   <div class="form-group">
                     <label class="col-sm-2 control-label">harga_destinasi</label>
                     <div class="col-sm-12">
                         <textarea id="harga_destinasi" name="harga_destinasi" required="" placeholder="Enter harga_destinasi" class="form-control"></textarea>
                     </div>
                   </div>
                   <div class="form-group">
                     <label class="col-sm-2 control-label">contact_person</label>
                     <div class="col-sm-12">
                         <textarea id="contact_person" name="contact_person" required="" placeholder="Enter contact_person" class="form-control"></textarea>
                     </div>
                   </div>
      
                    <div class="col-sm-offset-2 col-sm-10">
                     <button type="submit" class="btn btn-primary" id="saveBtn" value="create">Save changes
                     </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
    

   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>  
<script type="text/javascript">
  $(function () {
      $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
    });
    var table = $('.data-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('destinasis.index')); ?>",
        columns: [
            {data: 'id', name: 'id'},
            {data: 'nama_destinasi', name: 'nama_destinasi'},
            {data: 'lokasi_destinasi', name: 'lokasi_destinasi'},
            {data: 'deskripsi_destinasi', name: 'deskripsi_destinasi'},
            {data: 'jenis_destinasi', name: 'jenis_destinasi'},
            {data: 'harga_destinasi', name: 'harga_destinasi'},
            {data: 'contact_person', name: 'contact_person'},
            {data: 'action', name: 'action', orderable: false, searchable: false},
        ]
    });
    $('#createNewDestinasi').click(function () {
        $('#saveBtn').val("create-destinasi");
        $('#destinasi_id').val('');
        $('#destinasiForm').trigger("reset");
        $('#modelHeading').html("Create New Destinasi");
        $('#ajaxModel').modal('show');
    });
    $('body').on('click', '.editDestinasi', function () {
      var destinasi_id = $(this).data('id');
      $.get("<?php echo e(route('destinasis.index')); ?>" +'/' + destinasi_id +'/edit', function (data) {
          $('#modelHeading').html("Edit Destinasi");
          $('#saveBtn').val("edit-destinasi");
          $('#ajaxModel').modal('show');
          $('#destinasi_id').val(data.id);
          $('#nama_destinasi').val(data.nama_destinasi);
          $('#lokasi_destinasi').val(data.lokasi_destinasi);
          $('#deskripsi_destinasi').val(data.deskripsi_destinasi);
          $('#jenis_destinasi').val(data.jenis_destinasi);
          $('#harga_destinasi').val(data.harga_destinasi);
          $('#contact_person').val(data.contact_person);
      })
   });
    $('#saveBtn').click(function (e) {
        e.preventDefault();
        $(this).html('Save');
    
        $.ajax({
          data: $('#destinasiForm').serialize(),
          url: "<?php echo e(route('destinasis.store')); ?>",
          type: "POST",
          dataType: 'json',
          success: function (data) {
     
              $('#destinasiForm').trigger("reset");
              $('#ajaxModel').modal('hide');
              table.draw();
         
          },
          error: function (data) {
              console.log('Error:', data);
              $('#saveBtn').html('Save Changes');
          }
      });
    });
    
    $('body').on('click', '.deleteDestinasi', function () {
     
        var destinasi_id = $(this).data("id");
        confirm("Are You sure want to delete !");
      
        $.ajax({
            type: "DELETE",
            url: "<?php echo e(route('destinasis.store')); ?>"+'/'+destinasi_id,
            success: function (data) {
                table.draw();
            },
            error: function (data) {
                console.log('Error:', data);
            }
        });
    });
     
  });
</script>
</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel-8-CRUD-using-ajax-master\resources\views/Destinasi.blade.php ENDPATH**/ ?>