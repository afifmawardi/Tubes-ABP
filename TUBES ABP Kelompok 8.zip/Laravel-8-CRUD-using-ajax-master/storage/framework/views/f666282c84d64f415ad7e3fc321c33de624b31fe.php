<!DOCTYPE html>
<html>
<head>
    <title>Penginapan Pariwisata Indonesia</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" rel="stylesheet">
</head>
<body>
    
<div class="container">
    <h1>Penginapan Pariwisata Indonesia</h1>
    <br>
    <a class="btn btn-success" href="javascript:void(0)" id="createNewPenginapan"> Create New Penginapan</a>
    <br>
    <table class="table table-bordered data-table">
        <thead>
            <tr>
                <th>No</th>
                <th>nama_penginapan</th>
                <th>lokasi_penginapan</th>
                <th>deskripsi_penginapan</th>
                <th>jenis_penginapan</th>
                <th>harga_penginapan</th>
                <th>contact_person</th>
                <th width="300px">Action</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>
   
<div class="modal fade" id="ajaxModel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="modelHeading"></h4>
            </div>
            <div class="modal-body">
                <form id="penginapanForm" name="penginapanForm" class="form-horizontal">
                   <input type="hidden" name="penginapan_id" id="penginapan_id">
                    <div class="form-group">
                        <label for="name" class="col-sm-2 control-label">nama_penginapan</label>
                        <div class="col-sm-12">
                            <input type="text" class="form-control" id="nama_penginapan" name="nama_penginapan" placeholder="Enter nama_penginapan" value="" maxlength="50" required="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">lokasi_penginapan</label>
                        <div class="col-sm-12">
                            <textarea id="lokasi_penginapan" name="lokasi_penginapan" required="" placeholder="Enter lokasi_penginapan" class="form-control"></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                       <label class="col-sm-2 control-label">deskripsi_penginapan</label>
                       <div class="col-sm-12">
                           <textarea id="deskripsi_penginapan" name="deskripsi_penginapan" required="" placeholder="Enter deskripsi_penginapan" class="form-control"></textarea>
                       </div>
                   </div>
                   <div class="form-group">
                      <label class="col-sm-2 control-label">jenis_penginapan</label>
                      <div class="col-sm-12">
                          <textarea id="jenis_penginapan" name="jenis_penginapan" required="" placeholder="Enter jenis_penginapan" class="form-control"></textarea>
                      </div>
                   </div>
                   <div class="form-group">
                     <label class="col-sm-2 control-label">harga_penginapan</label>
                     <div class="col-sm-12">
                         <textarea id="harga_penginapan" name="harga_penginapan" required="" placeholder="Enter harga_penginapan" class="form-control"></textarea>
                     </div>
                   </div>
                   <div class="form-group">
                     <label class="col-sm-2 control-label">contact_person</label>
                     <div class="col-sm-12">
                         <textarea id="contact_person" name="contact_person" required="" placeholder="Enter contact_person" class="form-control"></textarea>
                     </div>
                   </div>
      
                    <div class="col-sm-offset-2 col-sm-10">
                     <button type="submit" class="btn btn-primary" id="saveBtn" value="create">Save changes
                     </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
    

   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>  
<script type="text/javascript">
  $(function () {
      $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
    });
    var table = $('.data-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('penginapans.index')); ?>",
        columns: [
            {data: 'id', name: 'id'},
            {data: 'nama_penginapan', name: 'nama_penginapan'},
            {data: 'lokasi_penginapan', name: 'lokasi_penginapan'},
            {data: 'deskripsi_penginapan', name: 'deskripsi_penginapan'},
            {data: 'jenis_penginapan', name: 'jenis_penginapan'},
            {data: 'harga_penginapan', name: 'harga_penginapan'},
            {data: 'contact_person', name: 'contact_person'},
            {data: 'action', name: 'action', orderable: false, searchable: false},
        ]
    });
    $('#createNewPenginapan').click(function () {
        $('#saveBtn').val("create-penginapan");
        $('#penginapan_id').val('');
        $('#penginapanForm').trigger("reset");
        $('#modelHeading').html("Create New Penginapan");
        $('#ajaxModel').modal('show');
    });
    $('body').on('click', '.editPenginapan', function () {
      var penginapan_id = $(this).data('id');
      $.get("<?php echo e(route('penginapans.index')); ?>" +'/' + penginapan_id +'/edit', function (data) {
          $('#modelHeading').html("Edit penginapan");
          $('#saveBtn').val("edit-penginapan");
          $('#ajaxModel').modal('show');
          $('#penginapan_id').val(data.id);
          $('#nama_penginapan').val(data.nama_penginapan);
          $('#lokasi_penginapan').val(data.lokasi_penginapan);
          $('#deskripsi_penginapan').val(data.deskripsi_penginapan);
          $('#jenis_penginapan').val(data.jenis_penginapan);
          $('#harga_penginapan').val(data.harga_penginapan);
          $('#contact_person').val(data.contact_person);
      })
   });
    $('#saveBtn').click(function (e) {
        e.preventDefault();
        $(this).html('Save');
    
        $.ajax({
          data: $('#penginapanForm').serialize(),
          url: "<?php echo e(route('penginapans.store')); ?>",
          type: "POST",
          dataType: 'json',
          success: function (data) {
     
              $('#penginapanForm').trigger("reset");
              $('#ajaxModel').modal('hide');
              table.draw();
         
          },
          error: function (data) {
              console.log('Error:', data);
              $('#saveBtn').html('Save Changes');
          }
      });
    });
    
    $('body').on('click', '.deletePenginapan', function () {
     
        var penginapan_id = $(this).data("id");
        confirm("Are You sure want to delete !");
      
        $.ajax({
            type: "DELETE",
            url: "<?php echo e(route('penginapans.store')); ?>"+'/'+penginapan_id,
            success: function (data) {
                table.draw();
            },
            error: function (data) {
                console.log('Error:', data);
            }
        });
    });
     
  });
</script>
</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel-8-CRUD-using-ajax-master\resources\views/Penginapan.blade.php ENDPATH**/ ?>